export class Inventory {
    constructor(ctx, w, h) {
        this.ctx = ctx;
        this.w = w;
        this.h = h;
    }

    render() {

    }

    update(dt, keys, mouse) {

    }
}